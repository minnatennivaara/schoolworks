/*Täällä pitäisi luoda tietokanta ja ajaa tämä skripti sitten phpmyadminin avulla.*/
/*ok. teen niin*/

create database if not exists tehtavalista;

use tehtavalista;

drop table if exists task;


create table task (
id int auto_increment primary key,
description varchar(255) not null,
done boolean default fase,
added timestamp default current_timestamp
)